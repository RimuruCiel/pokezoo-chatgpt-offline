using UnityEngine;

// Inventory UI placeholder - hiển thị danh sách thú đã bắt (yêu cầu hệ thống lưu creatures)
public class InventoryUI : MonoBehaviour
{
    public void Open()
    {
        Debug.Log("Inventory mở (chưa implement hiển thị chi tiết).");
    }
}