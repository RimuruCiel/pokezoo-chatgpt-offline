using UnityEngine;
using UnityEngine.SceneManagement;

// MenuManager: quản lý menu chính (Tiếp tục, New Game, Kho thú, Cường hoá, Cửa hàng, Cài đặt, Thoát)
public class MenuManager : MonoBehaviour
{
    public void NewGame()
    {
        // Xóa save cũ (nếu có) - implement SaveManager.ClearSave() nếu cần.
        Debug.Log("Bắt đầu trò chơi mới...");
        SceneManager.LoadScene("World");
    }

    public void ContinueGame()
    {
        Debug.Log("Tiếp tục trò chơi...");
        SceneManager.LoadScene("World");
    }

    public void OpenInventory()
    {
        Debug.Log("Mở kho thú...");
        // load UI panel
    }

    public void OpenUpgrade()
    {
        Debug.Log("Mở cường hoá...");
    }

    public void OpenShop()
    {
        Debug.Log("Mở cửa hàng...");
        SceneManager.LoadScene("Shop");
    }

    public void QuitGame()
    {
        Debug.Log("Thoát game.");
        Application.Quit();
    }
}