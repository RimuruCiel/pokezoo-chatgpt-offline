using UnityEngine;

// Shop UI placeholder: gọi ShopSystem để mua item
public class ShopUI : MonoBehaviour
{
    public ShopSystem shopSystem;

    public void BuyWithGoldIndex(int idx)
    {
        if (shopSystem == null) { Debug.Log("ShopSystem chưa gắn"); return; }
        shopSystem.BuyWithGold(idx);
    }

    public void BuyWithDiamondsIndex(int idx)
    {
        if (shopSystem == null) { Debug.Log("ShopSystem chưa gắn"); return; }
        shopSystem.BuyWithDiamonds(idx);
    }
}