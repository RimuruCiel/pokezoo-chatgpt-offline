Pokezoo Chat GPT - Final Unity Project (Landscape, Default Icon)
===============================================================

This package is prepared for Unity 2022.3 LTS, 2D top-down, landscape orientation.
It contains scripts, placeholder sprites (player + 6 creatures), UI scripts and instructions.
I CANNOT build an APK here. You must use Unity Editor (on a PC/Mac) or a cloud build service to create the APK.
Below are exact steps to open and build the APK targeting Android (landscape) following your device specs (Android 13, Redmi Note 10 Pro).

1) Requirements
- Unity Hub + Unity Editor 2022.3.x (install Android Build Support, OpenJDK, SDK/NDK).
- OR use Unity Cloud Build / GitHub Actions with unity-builder (if you don't have a PC).

2) Importing project
- Create new 2D Unity project (Unity 2022.3 LTS).
- Close Unity. Copy the 'Assets' and 'ProjectSettings/ProjectVersion.txt' from this zip into your Unity project folder (overwrite ProjectVersion.txt).
- Open project in Unity.

3) Scene setup (quick)
- Create scenes: World, Battle, Shop, Menu in Assets/Scenes.
- Create empty GameObject 'Managers' and attach CurrencyManager, SaveManager, ShopSystem, BlessingSystem components.
- Create Player GameObject: SpriteRenderer (assign Assets/Sprites/Player/player_cartoon.png), Rigidbody2D (Kinematic), BoxCollider2D, attach PlayerController.
- Create several Creature prefabs using Assets/Sprites/Creatures/creature_1.png ... creature_6.png and attach Creature.cs and SimpleAI.cs scripts.
- For Ma-creatures (auto-capture), enable isSpirit in Creature component.
- Set RewardGold and RewardDiamonds to 1000 and 100 respectively (default in script).

4) Landscape & icon settings
- File -> Build Settings -> Player Settings -> Resolution and Presentation -> Default Orientation = Landscape Left/Auto.
- Player Settings -> Icon: assign Assets/Sprites/UI/app_icon_512.png to Android icon.
- Graphics: keep 2D/URP settings. Target API: Android 13 (API 33). Scripting Backend: IL2CPP, Target Architecture: ARM64.
- Set Application identifier to: com.chatgpt.pokezoo

5) Build APK (Debug)
- File -> Build Settings -> Android -> Switch Platform.
- Build -> choose location, name: pokezoo_chatgpt_debug.apk
- Copy APK to your phone and install (enable Unknown Sources / Allow from this source).

6) If you don't have a PC: options to get an APK
A) Ask a friend/PC to run the steps above and send you the APK.
B) Use Unity Cloud Build (requires Unity organization & repo). Steps:
   - Create repository on GitHub with this project.
   - Enable Unity Cloud Build and link repo.
   - Configure build target Android, Unity version 2022.3.x, and trigger build.
C) Use a third-party paid build service (search for "Unity build service APK build").

7) Installing APK on phone
- Transfer pokezoo_chatgpt_debug.apk to phone (USB, Google Drive, Telegram).
- On phone, open file -> Install. You may need to allow install from unknown sources.
- Open game. Enjoy!

Notes:
- This package contains placeholder sprites (non-copyright) and scripts configured for Vietnamese UI.
- I cannot perform the build into an APK in this environment; if you want, I can prepare a GitHub repo structure and CI config for Unity Cloud Build to make remote building easier.